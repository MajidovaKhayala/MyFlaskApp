from flask import Flask, render_template_string

app = Flask(__name__)

index_html = """
<!DOCTYPE html>
<html lang="az">
<head>
  <meta charset="UTF-8">
  <title>Monitorinq Paneli</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: sans-serif;
      height: 100vh;
      display: flex;
    }
    .sidebar {
      width: 200px;
      background-color: #2c3e50;
      color: white;
      display: flex;
      flex-direction: column;
      transition: width 0.3s;
    }
    .sidebar.collapsed {
      width: 60px;
    }
    .sidebar.collapsed a {
      text-align: center;
      font-size: 12px;
    }
    .sidebar a {
      padding: 15px;
      text-decoration: none;
      color: white;
      transition: background 0.3s;
    }
    .sidebar a:hover {
      background-color: #34495e;
    }
    .toggle-btn {
      background-color: #1abc9c;
      color: white;
      border: none;
      padding: 10px;
      cursor: pointer;
      font-size: 16px;
      text-align: left;
    }
    .header-logo {
      padding: 10px;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .header-logo img#logo-full {
      width: 180px;
    }
    .header-logo img#logo-mini {
      width: 40px;
    }
    .content {
      flex-grow: 1;
    }
    iframe {
      width: 100%;
      height: 100%;
      border: none;
    }
  </style>
</head>
<body>
  <div class="sidebar" id="sidebar">
    <div class="header-logo">
      <img src="/static/IKTALOGOAG.png" alt="Logo" id="logo-full" />
      <img src="/static/simvol-white.png" alt="Logo" id="logo-mini" style="display: none;" />
    </div>
    <button class="toggle-btn" onclick="toggleSidebar()">☰ Menyu</button>
    <a href="/general" target="contentFrame">1. Ümumi</a>
    <a href="/telekom" target="contentFrame">2. Telekom</a>
    <a href="/poct" target="contentFrame">3. Poçt</a>
    <a href="/radiospektr" target="contentFrame">4. Radiospektr</a>
  </div>
  <div class="content">
    <iframe name="contentFrame" src="/general"></iframe>
  </div>
  <script>
    function toggleSidebar() {
      const sidebar = document.getElementById('sidebar');
      const fullLogo = document.getElementById('logo-full');
      const miniLogo = document.getElementById('logo-mini');
      sidebar.classList.toggle('collapsed');
      const collapsed = sidebar.classList.contains('collapsed');
      fullLogo.style.display = collapsed ? 'none' : 'block';
      miniLogo.style.display = collapsed ? 'block' : 'none';
    }
  </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(index_html)

@app.route('/general')
def general():
    return render_template_string("<h1>Ümumi Bölmə</h1><p>İKTA fəaliyyəti ilə bağlı ümumi məlumatlar.</p>")

@app.route('/telekom')
def telekom():
    return render_template_string("<h1>Telekom Bölməsi</h1><p>Telekommunikasiya məlumatları.</p>")

@app.route('/poct')
def poct():
    return render_template_string("<h1>Poçt Bölməsi</h1><p>Poçt xidmətləri haqqında məlumat.</p>")

@app.route('/radiospektr')
def radiospektr():
    return render_template_string("<h1>Radiospektr Bölməsi</h1><p>Radiospektrlə bağlı məlumatlar.</p>")
